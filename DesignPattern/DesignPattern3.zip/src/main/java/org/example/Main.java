package org.example;

import org.example.view.BankUI;

public class Main { // Design pattern
    public static void main(String[] args) {
        BankUI.main(args);
    }
}